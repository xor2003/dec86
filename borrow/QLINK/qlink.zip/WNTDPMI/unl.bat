@echo off
wntdpmi/unload
