// Wrapper to include test data with proper headers
#include <cstddef>

// Include test data files - PKLITE
#include "testdata/compressed/pklite_100.cc"
#include "testdata/compressed/pklite_112.cc"
#include "testdata/compressed/pklite_115.cc"
#include "testdata/compressed/pklite_120.cc"
#include "testdata/compressed/pklite_150.cc"
#include "testdata/compressed/pklite_E_112.cc"
#include "testdata/compressed/pklite_E_115.cc"
#include "testdata/compressed/pklite_E_120.cc"

// Include test data files - LZEXE
#include "testdata/compressed/z90.cc"
#include "testdata/compressed/z91.cc"
#include "testdata/compressed/z91e.cc"

// Include test data files - Knowledge Dynamics
#include "testdata/compressed/dot.cc"
#include "testdata/compressed/lex.cc"
#include "testdata/compressed/tntega.cc"

// Include test data files - EXEPACK
#include "testdata/compressed/exepack_hello.cc"
#include "testdata/compressed/exepack_masm400.cc"
#include "testdata/compressed/exepack_masm500.cc"
#include "testdata/compressed/exepack_masm510.cc"
